<?php $__env->startSection('inner-content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            
            <div class="col-xs-12 col-md-3" style="display: inline-block;">
                <div class="card">                    
                    <div class="card-body" align="center">
                           <?php echo e(number_format($jobCount)); ?> - Jobs
                    <!-- [end] -->
                    </div>
                </div>                
            </div>


            <div class="col-xs-12 col-md-3" style="display: inline-block;">
                <div class="card">                    
                    <div class="card-body" align="center">
                           <?php echo e(number_format($applicantCount)); ?> - Applicants
                    <!-- [end] -->
                    </div>
                </div>                
            </div>



        </div>
    </div>

<div class="col-lg-12" style="margin: 11.4%;"></div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logged_user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>