	
			<div class="<?php echo e(Auth::user()->role==3 ? 'col-lg-12' : 'col-lg-9'); ?> post-list">

		<div class="single-post job-experience">
					<h4 class="single-title">Basic Details
					<?php if(Auth::user()->role==0): ?> 
					 <a href="<?php echo e(url('job')); ?>/appllyToJob#step-1" class="btn pull-right btn-info btn-sm">Modify</a>
					<?php endif; ?>
				</h4>
					<table class="table">
						<tr>
							<td>Name</td>
							<td><?php echo e($user->name); ?></td>
						</tr>
						<tr>
							<td>Email</td>
							<td><?php echo e($user->email); ?></td>
						</tr>
						<tr>
							<td>Phone Number</td>
							<td><?php echo e($user->phone_num); ?></td>
						</tr>
						<tr>
							<td>Address</td>
							<td><?php echo e($user->address); ?></td>
						</tr>
						<tr>
							<td>Date of Birth</td>
							<td><?php echo e($user->dob); ?></td>
						</tr>
						<tr>
							<td>Gender</td>
							<td><?php echo e($user->sex); ?></td>
						</tr>
						<tr>
							<td>Marital Status</td>
							<td><?php echo e($user->marital_status); ?></td>
						</tr>								 
					</table>
				</div>

				<div class="single-post job-experience">
					<h4 class="single-title">Education
						<?php if(Auth::user()->role==0): ?> <a href="<?php echo e(url('job')); ?>/appllyToJob#step-2" class="btn pull-right btn-info btn-sm">Add</a>	<?php endif; ?>
					</h4>
					<?php if(count($institutions)>0): ?>
					<?php $__currentLoopData = $institutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<table class="table table-striped" style="margin-top: 20px;">

						<tr>
							<td>  Name</td>
							<td><?php echo e($institution->name); ?></td>
						</tr>
						<tr>
							<td>  Qualification</td>
							<td>  <?php echo e($institution->degree_resolve); ?> </td>
						</tr>
						<tr>
							<td> Course </td>
							<td><?php echo e($institution->course); ?> </td>
						</tr>
						<tr>
							<td>Grade</td>
							<td><?php echo e($institution->grade_resolve); ?></td>
						</tr>
						<tr>
							<td> Date </td>
							<td> <?php echo e($institution->start_year); ?> to <?php echo e(is_null($institution->end_year) ? 'date' : $institution->end_year); ?>

							</tr>
							<tr>
								<td>Decription</td>
								<td><?php echo e($institution->description); ?></td>
							</tr>
							<?php if(Auth::user()->role==0): ?> 
					<tr>

						<td>Action</td>
						<td>
							<a class="btn btn-sm btn-success" href="<?php echo e(url('job')); ?>/delete?model=institutions&id=<?php echo e($institution->id); ?>&url=profile?id=<?php echo e($user->id); ?>">Delete </a>
						</td>   
					</tr>	<?php endif; ?>
						</table>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
							<h4>No Record Found</h4>
						<?php endif; ?>

					</div>


					<div class="single-post job-experience">
						<h4 class="single-title">Past Employement
							<?php if(Auth::user()->role==0): ?> 
							<a href="<?php echo e(url('job')); ?>/appllyToJob#step-3" class="btn pull-right btn-info btn-sm">Add</a>	<?php endif; ?>
						</h4>
						<?php if(count($pastEmps)>0): ?>
						<?php $__currentLoopData = $pastEmps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $past): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<table class="table table-striped">
							<tr>
								<td>  Name</td>

								<td><?php echo e($past->organization); ?></td>
							</tr>
							<tr>
								<td>  Role</td>
								<td>  <?php echo e($past->role); ?> </td>
							</tr>
							<tr>
								<td> Level </td>
								<td><?php echo e($past->job_level_real); ?> </td>
							</tr>
							<tr>
								<td> Address </td>
								<td><?php echo e($past->address); ?> </td>
							</tr>
							<tr>
								<td>Date</td>
								<td> <?php echo e($past->from); ?> to <?php echo e(is_null($past->to) ? 'date' : $past->to); ?></td>
							</tr>
							<tr>
								<td>Description</td>
								<td><?php echo e($past->job_desc); ?></td> 
							</tr>
							<?php if(Auth::user()->role==0): ?> 
												<tr>

						<td>Action</td>
						<td>
							<a class="btn btn-sm btn-success" href="<?php echo e(url('job')); ?>/delete?model=empPastEmp&id=<?php echo e($past->id); ?>&url=profile?id=<?php echo e($user->id); ?>">Delete </a>
						</td>   
					</tr>	<?php endif; ?>
						</table>
						<hr>		
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
							<h4>No Record Found</h4>
						<?php endif; ?>
					</div>


					<div class="single-post job-experience">
						<h4 class="single-title">Certification
								<?php if(Auth::user()->role==0): ?> 
							<a href="<?php echo e(url('job')); ?>/appllyToJob#step-4" class="btn pull-right btn-info btn-sm">Add</a>
									<?php endif; ?>
						</h4>
						<?php if(count($certifications)>0): ?>
						   <?php $__currentLoopData = $certifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<table class="table table-striped">
							<tr>
								<td> Title</td>
								<td><?php echo e($certification->title); ?></td>
							</tr>
							<tr>
								<td> Type</td> 
								<td>  <?php echo e($certification->cert_type); ?> </td>
							</tr>
							<tr>
								<td> Year Received </td>
								<td><?php echo e($certification->year_received); ?> </td> 
							</tr>
							<?php if(Auth::user()->role==0): ?> 
						<tr>

						<td>Action</td>
						<td>
							<a class="btn btn-sm btn-success" href="<?php echo e(url('job')); ?>/delete?model=Certification&id=<?php echo e($certification->id); ?>&url=profile?id=<?php echo e($user->id); ?>">Delete </a>
						</td>   
					</tr>	<?php endif; ?>
						</table>
						<hr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
							<h4>No Record Found</h4>
						<?php endif; ?>
					</div>

					<div class="single-post job-experience">
						<h4 class="single-title">Document
							<?php if(Auth::user()->role==0): ?> 
							<a href="<?php echo e(url('job')); ?>/appllyToJob#step-5" class="btn pull-right btn-info btn-sm">Add</a>
							<?php endif; ?>
						</h4>
						<?php if(count($documents)>0): ?>
					 <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <table class="table table-striped">
					 <tr>
					 <td> Type</td> 
 						<td>  <?php echo e($document->documenttype->docname); ?> </td> 
 						</tr>
 						<tr>
 						<td>Action</td>
                         <td>

                            <div class="dropdown">
                                <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Action
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton"> 
                                     <a class="dropdown-item" target="_blank" href="<?php echo e(url('job')); ?>/download?id=<?php echo e($document->id); ?>"  >Download Document</a> 
                                 <?php if(Auth::user()->role==0): ?>   
                                  <a class="dropdown-item" href="<?php echo e(url('job')); ?>/delete?model=document&id=<?php echo e($document->id); ?>&url=profile?id=<?php echo e($user->id); ?>">Delete</a> 
                                  	<?php endif; ?>
                                </div>
                            </div>


                        </td> 
                        </tr> 
                    </table></hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
							<h4>No Record Found</h4>
						<?php endif; ?>
					</div>
 
					<div class="single-post job-experience">
						<h4 class="single-title">Refrees
							<?php if(Auth::user()->role==0): ?> <a href="<?php echo e(url('job')); ?>/appllyToJob#step-6" class="btn pull-right btn-info btn-sm">Add</a>	<?php endif; ?></h4>
						<?php if(count($refrees)>0): ?>
						<?php $__currentLoopData = $refrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<table class="table table-striped">
					<tr>
						<td> Name</td>
						<td><?php echo e($refree->ref_name); ?></td>
					</tr>
					<tr>
						<td> Position</td>
						<td>  <?php echo e($refree->ref_prof); ?> </td>
					</tr>
					<tr>
						<td> Email </td> 
						<td><?php echo e($refree->ref_email); ?> </td>
					</tr>
					<tr>
						<td>Phone</td>
						<td><?php echo e($refree->ref_phone); ?></td> 
					</tr><?php if(Auth::user()->role==0): ?> 
					<tr>

						<td>Action</td>
						<td>
							<a class="btn btn-sm btn-success" href="<?php echo e(url('job')); ?>/delete?model=reference&id=<?php echo e($refree->id); ?>&url=profile?id=<?php echo e($user->id); ?>">Delete </a>
						</td>   
					</tr>	<?php endif; ?>
						</table>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
							<h4>No Record Found</h4>
						<?php endif; ?>
					</div>

