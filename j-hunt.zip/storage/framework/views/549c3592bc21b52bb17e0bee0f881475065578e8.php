


<div class="col-lg-3 sidebar">
	<div class="single-slidebar">
		<h4>Menu </h4>
		<ul class="nav nav-pills flex-column">
			<li class="nav-item">
				<a class="nav-link"  href="<?php echo e(url('job/profile')); ?>?id=<?php echo e(Auth::user()->id); ?>">My Profile</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="<?php echo e(url('job')); ?>/jobAppliedFor?user_id=<?php echo e(Auth::user()->id); ?>">Job's Applied For</a>
			</li>

		</ul>
	</div>

</div>