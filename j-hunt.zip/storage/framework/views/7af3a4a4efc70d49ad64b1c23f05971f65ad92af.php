<?php $__env->startSection('content'); ?>
<div class="col-lg-2 sidebar">
  <?php echo $__env->make('sidebars.admin_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<div class="col-lg-10 post-list">
 <?php echo $__env->yieldContent('inner-content'); ?>
</div>
<?php $__env->stopSection(); ?>