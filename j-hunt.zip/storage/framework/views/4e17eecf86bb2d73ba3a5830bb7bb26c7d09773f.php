	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="codepixer">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title><?php echo $__env->yieldContent('title'); ?></title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
		<style type="text/css">
			.bold{
				font-weight: bold;
			}
			.hide{
				display: none;
			}
			.section-gap {
				    padding: 0px 0 !important;
				}
		</style>
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="<?php echo e(asset('css/linearicons.css')); ?>">
			<link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
			<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
			<link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
			<link rel="stylesheet" href="<?php echo e(asset('css/nice-select.css')); ?>">					
			<link rel="stylesheet" href="<?php echo e(asset('css/animate.min.css')); ?>">
			<link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.css')); ?>">
			<link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css')); ?>">
  <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/plugins/toastr/toastr.min.css')); ?>" rel="stylesheet">
			<?php echo $__env->yieldContent('css'); ?>
		</head>
		<body>

			  <header id="header" id="home">
			    <div class="container">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo">
				        <a href="index.html"><img src="img/logo.png" alt="" title="" /></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="/">Home</a></li>
				             <?php if(!Auth::guest() && Auth::user()->role==0): ?>
									       
				          <li><a href="<?php echo e(url('job')); ?>/profile?id=<?php echo e(Auth::user()->id); ?>">Profile</a></li>
				          <li><a href="<?php echo e(url('job')); ?>/jobAppliedFor?user_id=<?php echo e(Auth::user()->id); ?>">Job Applied For</a></li>
				          <?php endif; ?>
				          <?php if(Auth::guest()): ?>
				          <li><a   href="<?php echo e(route('register')); ?>"  >Signup</a></li>
				          <li><a  href="<?php echo e(route('login')); ?>"  >Login</a></li>	
				          <?php else: ?>
				          <li><a  href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form22').submit();">Logout
                               </a>
                            </li>
								<form id="logout-form22" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                </form>
				          <?php endif; ?>
				          <?php if(!Auth::guest() && Auth::user()->role==3): ?>
									       
				          <li><a  href="#" data-toggle="modal" data-target="#addjobs">Add Position</a></li>	
				          <?php if(Request::is('job/viewApplicant')): ?>
				           <li><a class="ticker-btn"  data-toggle="modal" data-target="#approveReject" href="javascript::void()"  onclick="sessionStorage.setItem('checkid',0)">Approve Selected</a></li>
				           <?php endif; ?>
				          	  <?php endif; ?>  			          				          
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header><!-- #header -->

			 <?php echo $__env->yieldContent('content'); ?> 
<!-- Start callto-action Area -->
		 		
			<!-- End calto-action Area -->			
		
			<!-- start footer Area -->		<br>
			<?php if(Request::is('password/reset')): ?> <br><br><br> <?php endif; ?>
			<footer class="footer-area section-gap">
				<div class="container">
					
					<div class="row footer-bottom d-flex justify-content-between">
						<p class="col-lg-8 col-sm-12 footer-text m-0 text-white">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved 
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						</p>
						
					</div>
				</div>
			</footer>
			<!-- End footer Area -->		

			<script src="<?php echo e(asset('js/vendor/jquery-2.2.4.min.js')); ?>"></script>
			<script src="<?php echo e(asset('js/popper.min.js')); ?>" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="<?php echo e(asset('js/vendor/bootstrap.min.js')); ?>"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="<?php echo e(asset('js/easing.min.js')); ?>"></script>			
			<script src="<?php echo e(asset('js/hoverIntent.js')); ?>"></script>
			<script src="<?php echo e(asset('js/superfish.min.js')); ?>"></script>	
			<script src="<?php echo e(asset('js/jquery.ajaxchimp.min.js')); ?>"></script>
			<script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>	
			<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>			
			<script src="<?php echo e(asset('js/jquery.sticky.js')); ?>"></script>
			<script src="<?php echo e(asset('js/jquery.nice-select.min.js')); ?>"></script>			
			<script src="<?php echo e(asset('js/parallax.min.js')); ?>"></script>		
			<script src="<?php echo e(asset('js/mail-script.js')); ?>"></script>	
			  <script src="<?php echo e(asset('assets/plugins/toastr/toastr.min.js')); ?>"></script>

        <script type="text/javascript" src="<?php echo e(asset('assets/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('assets/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js')); ?>"></script>
			<script src="<?php echo e(asset('js/main.js')); ?>"></script>

        <script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>

        <script type="text/javascript">
        	$(function(){
        		<?php if(session()->has('login')): ?>
  			  	$('#loginModal').modal('show');	
  			  	<?php endif; ?>

				  $("#checkAll").change(function () {
                      $("input:checkbox").prop('checked', $(this).prop("checked"));
                    });

        		$('.applicantProfileLink').click(function(e){
					e.preventDefault();
					console.log($(this).attr('href'));
					$('#applicantProfile').load($(this).attr('href'));
				})
        				<?php if(session()->has('message')): ?>
									 
								toastr.error('<?php echo e(session('message')); ?>');
									 
									<?php endif; ?>
        		   $('.datepicker').datepicker({
				        format: "yyyy-mm-dd",
				        autoclose: true
				     });

   				$('.datepicker2').datepicker({
				        format: "yyyy",
				        autoclose: true,
				          viewMode: "years",
    					 minViewMode: "years"
				     });

                    $('.wysiwyg').wysihtml5();

        	 });

        	function checkempty(value){
    	   		if(value==''){
    	   			return toastr.info('Some field(s) are empty');
    	   		}
    	   		return 0;
    	   	}
    	    function checkOwn($id){
    	    	// alert('d');
    	    	sessionStorage.setItem('checkid',$id);
    	    	$('#'+$id).trigger('click');
    	    }
    	    function unCheck(){
    	     
    	    	$('#'+sessionStorage.getItem('checkid')).trigger('click');
    	    
    	    }
     function processPost(formData,route,type=0){
    	   	$.post('<?php echo e(url('/')); ?>/'+route,formData,function(data,status,xhr){

    	 		if(data.status=='success'){
    	 			toastr.success(data.message);
    	 			 
    	 				 window.location.reload();
    	 		 
    	 			return true;
    	 		}

    	 		toastr.error(data.message);
    	 		return false;
    	 	})
    	   	}

     function resolvetype($type){
     	if($type==1){
     		return 'Apprroved';
     	}
     	return 'Rejected';
     }

   	function decideApplicant($type){

   		    $ids=$('.decision:checked').map(function() {return this.value;}).get();
		        if($ids.length<=0){
		          return toastr.error('No Applicant selected');
				}
				if($('#messsage').val()==''){
					return 'Please Specify '+resolvetype($type)+' message';
				}

			formData={
				ids:$ids,
				_token:'<?php echo e(csrf_token()); ?>',
				message:$('#messsage').val(),
				type:'decideApplicant',
				status:$type
			}

			$.post('<?php echo e(url('job')); ?>',formData,function(data,status,xhr){

				if(data.status=='success'){
					
					toastr.success(data.message);
					window.location.reload();
					return; 
				}
				return toastr.error(data.message);
			})

   	}

   	function sendEMail(){
   		$ids=$('.decision:checked').map(function() {return this.value;}).get();
   		if($ids.length<=0){
   			return toastr.error('No Applicant selected');
   		}
   		if($('#messsageMail').val()==''){
   			return 'Please Enter Message to Send';
   		}
   	formData={
				ids:$ids,
				_token:'<?php echo e(csrf_token()); ?>',
				message:$('#messsageMail').val(),
				type:'mailApplicant'
				 
			}

			$.post('<?php echo e(url('job')); ?>',formData,function(data,status,xhr){

				if(data.status=='success'){
					
					toastr.success(data.message);
					unCheck();
					 $('.modal').modal('hide');
					return; 
				}
				return toastr.error(data.message);
			})
   	}

 function editListing(jobid){
 	$.get('<?php echo e(url('job')); ?>/apply?job_id='+jobid,function(data,status,xhr){
 

 		$(".titleText").val(data.message.title);
 		$('.job_desc').val(data.message.job_desc);
 		$('.job_ref').val(data.message.job_ref);
 		$('.min_sal').val(data.message.min_sal);
 		$('.max_sal').val(data.message.max_sal);
 		$('.required_exp').val(data.message.required_exp);
 		$('.min_exp').val(data.message.min_exp);
 		$('.max_exp').val(data.message.max_exp);
 		$('.level_id').val(data.message.level_id);
 		$('.location_id').val(data.message.location_id);
 		$('.qualification').val(data.message.qualification);
 		$('.date_expire').val(data.message.date_expire);
 		$('.otherskill').val(data.message.otherskill);
 		$('.jobid').val(data.message.id);
 		$('#addjobs').modal('show'); 
 	});

 }


   function setDescription(desc){
    	  	$('#genericdesc').html(desc);
  }
        </script>
			<?php echo $__env->yieldContent('script'); ?>	
		</body>
	</html>





