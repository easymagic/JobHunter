 
 <div id="step-5">

 	<div id="form-step-0" >
 		<div class="form-group">
            <form id="uplodaDoc">
 			<table class="table">
 				<tr>
 				
                    <td>
                        <label >Type:</label>
                     <select id="type" class="form-control type_id" name="type_id" required="">
                            <option selected="selected" value="">Select...</option>
                        <?php $__currentLoopData = $doctypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type->id); ?>"><?php echo e($type->docname); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>  
                    </td> 
                     <td>
                        <label >Upload:</label>
                        <input type="file" class="form-control document" name="document"  required> 
                    </td>                 
 				</tr>
                
 			</table>
            </form>
            <table class="table">
                <tr>
                    <td>
                        <div class="progress ">
                            <div class="progress-bar bg-info" id="progress">
                                
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
  <button  style="margin-left: 9px;" class="btn btn-md btn-info"  onclick="stepFive(0)">Upload</button>
                

                         <?php if(count($documents)>0): ?>
            <table class="table table-striped" style="margin-top: 20px;">
                <tr> 
                    <td> Type</td> 
                    <td>Action</td>
                </td>
                </tr>
                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr> 
                      <td>  <?php echo e($document->documenttype->docname); ?> </td> 
                         <td>
                            <div class="dropdown">
                                <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Action
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton"> 
                                     <a class="dropdown-item" target="_blank" href="<?php echo e(url('job')); ?>/download?id=<?php echo e($document->id); ?>"  >Download Document</a> 
                                    <a class="dropdown-item" href="<?php echo e(url('job')); ?>/delete?model=document&id=<?php echo e($document->id); ?>&url=appllyToJob?job_id=<?php echo e(isset($_GET['job_id'])? $_GET['job_id'] : 0); ?>#step-5">Delete</a> 
                                </div>
                            </div>


                        </td>  


                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php endif; ?>
 		</div>
 	</div>

 </div>
 <script type="text/javascript">
 	 function stepFive(type){
                submitJobcard('uplodaDoc','<?php echo e(url('job')); ?>','progress');
    	 }
function loadDocument(url){
    window.location=url;
}
 function submitJobcard(formid,url,progress){
     formdata= new FormData($('#'+formid)[0]);
     formdata.append('_token','<?php echo e(csrf_token()); ?>');
     formdata.append('type','stepFive');
     formdata.append('user_id','<?php echo e(Auth::user()->id); ?>');
     $.ajax({
        url: url,
        type: 'POST',
        data: formdata,
        cache: false,
        contentType: false,
        processData: false,
        success:function(data,status,xhr){
            if(data.status=='success'){
                toastr.success(data.message);
                setTimeout(function(){
                    window.location.reload();

                },2000);
                return;
            }
            return toastr.error(data.message);
        },
        xhr: function() {
            var myXhr = $.ajaxSettings.xhr();
            if (myXhr.upload) {
                // For handling the progress of the upload
                myXhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        percent=Math.round((e.loaded/e.total)*100,2);
                        $('#'+progress).css('width',percent+'%');
                        $('#'+progress+'_text').text(percent+'%');
                    }
                } , false);
            }
            return myXhr;
        }
    });

 }
 </script>