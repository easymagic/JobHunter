<?php $__env->startSection('title',"Profile"); ?>

<?php $__env->startSection('content'); ?>
<section class="banner-area relative" id="home" style="">	
	<div class="overlay overlay-bg"></div>
	<div class="container">
		<div class="row d-flex align-items-center justify-content-center">
			<div class="about-content col-lg-12">
				<h1 class="text-white">
					<?php echo e(Auth::user()->name); ?>'s Profile'				
				</h1>	
				<p class="text-white link-nav"><a href="<?php echo e(url('/')); ?>">Home </a>  <span class="lnr lnr-arrow-left"></span>  </p>
			</div>											
		</div>
	</div>
</section>

<section class="post-area section-gap">
	<div class="" style="margin: 20px;">

		<div class="row justify-content-center d-flex">

						<?php echo $__env->make('category.partials.sidebar2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<?php echo $__env->make('category.partials.profile', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<?php echo $__env->make('category.partials.addJobModal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		 		<?php echo $__env->make('category.partials.genericModal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 
				</div>
			</div>
		</div>
	</section>
	<?php $__env->stopSection(); ?>

	
<?php echo $__env->make('layouts.cat_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>