<?php $__env->startSection('inner-content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            
                <!-- <div class="card-header"><?php echo e(__('Change Password')); ?></div> -->

<div style="
    border-bottom: 3px solid #8c76f7;
    margin-bottom: 17px;
    font-size: 18px;
">
    Update Job.
</div>

<?php echo $__env->make('notifications.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="col-md-12" align="right">
    <a href="/jobs" class="btn btn-primary btn-sm">Back</a>
</div>


            
                    <form method="POST" action="/jobs/<?php echo e($job->id); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Role')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control" name="role" value="<?php echo e($job->role); ?>" required autofocus>

                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                            <div class="col-md-6">
                            	<textarea class="form-control" name="description"><?php echo e($job->description); ?></textarea>

                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Recruitment Type')); ?></label>

                            <div class="col-md-6">
                                <select data-value="<?php echo e($job->jb_recruitment_type_id); ?>" name="jb_recruitment_type_id" class="form-control" required="">
                                    <?php $__currentLoopData = $jb_recruitment_type_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jb_recruitment_type_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($jb_recruitment_type_id->id); ?>"><?php echo e($jb_recruitment_type_id->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Salary Range')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control" name="salary_range" required autofocus value="<?php echo e($job->salary_range); ?>" required="">

                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Address')); ?></label>

                            <div class="col-md-6">
                        <textarea class="form-control" name="address" required=""><?php echo e($job->address); ?></textarea>
                            </div>
                        </div>



                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Update Job')); ?>

                                </button>

                            </div>
                        </div>
                    </form>


<!-- recruitment-level -->
                    <div style="border-bottom: 1px solid #000;">
                        <b style="color: #000;">Required Recruitment Level</b>
                    </div>

                    <div class="col-lg-12"></div>


<!-- certificates -->
                    <div style="border-bottom: 1px solid #000;">
                        <b style="color: #000;">Required Certificates</b>
                    </div>

                    <div class="col-lg-12"></div>







<!-- skills -->
                    <div style="border-bottom: 1px solid #000;">
                        <b style="color: #000;">Required Skills</b>
                    </div>

                    <div class="col-lg-12"></div>




<!-- competence -->
                    <div style="border-bottom: 1px solid #000;">
                        <b style="color: #000;">Required Competences</b>
                    </div>

                    <div class="col-lg-12"></div>














        </div>
    </div>

<div class="col-lg-12" style="margin: 11.4%;"></div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logged_user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>