                <?php if(session()->has('message')): ?>
                  
                  <div class="alert alert-info"><?php echo e(session()->get('message')); ?></div>
 
                <?php endif; ?>