<?php $__env->startSection('title','Job List'); ?>

<?php $__env->startSection('css'); ?>
<!-- Include SmartWizard CSS -->
<link href="<?php echo e(asset('dist/css/smart_wizard.css')); ?>" rel="stylesheet" type="text/css" />

<!-- Optional SmartWizard theme -->
<link href="<?php echo e(asset('dist/css/smart_wizard_theme_circles.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('dist/css/smart_wizard_theme_arrows.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('dist/css/smart_wizard_theme_dots.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="banner-area relative" id="home">	
	<div class="overlay overlay-bg"></div>
	<div class="container">
		<div class="row d-flex align-items-center justify-content-center">
			<div class="about-content col-lg-12">
				<h1 class="text-white">
					Applicant Applied for <?php echo e($jobtitle); ?>				
				</h1>	
				<p class="text-white link-nav"><a href="<?php echo e(url('/')); ?>">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a <?php if(isset($_GET['job_id'])): ?> href="<?php echo e(url('job')); ?>/apply?job_id=<?php echo e($_GET['job_id']); ?>" <?php else: ?> href="<?php echo e(url('job')); ?>/profile"  <?php endif; ?> >Back </a></p>
			</div>											
		</div>
	</div>
</section>

<section class="post-area section-gap">
	<div class="" style="margin:20px;">
		<div class="row justify-content-center d-flex">
			<!-- include('category.partials.sidebar3') -->

			<?php echo $__env->make('category.partials.side_bar_search_applicants', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="col-lg-9 post-list">
				<?php if(count($applicantlists)>0): ?>
				<table class="table table-striped">
					<tr>
						<td><input type="checkbox" id="checkAll"></td>
						<td>Name</td>
						<td>Email</td>
						<td>Phone Number</td>
						<td>Status</td>
						<td>Action</td>
					</tr>
						<?php $__currentLoopData = $applicantlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><input type="checkbox" class="decision" id="decision<?php echo e($applicant->id); ?>" value="<?php echo e($applicant->id); ?>"></td>
						<td><?php echo e(ucwords($applicant->user->name)); ?></td>
						<td><?php echo e($applicant->user->email); ?></td>
						<td><?php echo e($applicant->user->phone_num); ?></td>
						<td><?php echo $applicant->resolve_status; ?></td>
						<td>
							 <div class="dropdown">
                                <button class="btn btn-success dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Action
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton"> 
                                     <a class="dropdown-item applicantProfileLink" href="<?php echo e(url('job')); ?>/profile?id=<?php echo e($applicant->user->id); ?>" data-toggle="modal" data-target="#profileView"  >View Profile</a> 
                                     <a class="dropdown-item" data-backdrop="false" href="javascript::void(0)"  data-toggle="modal" data-target="#approveReject" onclick="checkOwn('decision<?php echo e($applicant->id); ?>')" >Approve/Reject</a> 
                                     <a class="dropdown-item" target="_blank" href="" href="javascript::void(0)"  data-toggle="modal" data-backdrop="false" data-target="#mailApplicant" onclick="checkOwn('decision<?php echo e($applicant->id); ?>')" >Mail Applicant</a>  
                                     <!-- <a class="dropdown-item" target="_blank" href=""  >Schedule Interview</a>   -->
                                </div>
                            </div>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</table>
				<?php echo $applicantlists->appends(Request::capture()->except('page'))->render(); ?>

				<?php else: ?>
					<h4>No Applicant Found !! </h4>
				<?php endif; ?>

			</div>

		</div></div></section>

		 <?php echo $__env->make('category.partials.addJobModal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		 		<?php echo $__env->make('category.partials.genericModal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	 
<?php echo $__env->make('layouts.cat_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>