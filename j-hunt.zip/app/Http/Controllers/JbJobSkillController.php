<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JbJobSkillController extends Controller
{
    //
}
