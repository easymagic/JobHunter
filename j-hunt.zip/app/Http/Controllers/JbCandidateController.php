<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JbCandidateController extends Controller
{
    //
}
