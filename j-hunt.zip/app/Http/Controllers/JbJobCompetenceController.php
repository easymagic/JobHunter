<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JbJobCompetenceController extends Controller
{
    //
}
