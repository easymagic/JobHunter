<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Jb\JbCandidateJob;
use App\Jb\JbJob;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function index(Request $request)
    {

        return view('home');
    }



    function indexTest(){
      return view('layouts.main');
    }


    function userDashboard(){
        return view('user.dashboard',[
          'jobCount'=>JbJob::count(),
          'applicantCount'=>JbCandidateJob::count()
        ]);
    }

}
