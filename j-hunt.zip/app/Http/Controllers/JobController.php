<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Notifications\UserNotification;

class JobController extends Controller
{


    public $allowed=['png','jpg','gif','PNG','jpeg','pdf','html'];
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function  __construct(Request $request){

       $this->middleware('auth');

    }

    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //\
        try{
        switch ($request->type) {
            case 'stepOne':
                # code...
                    return $this->stepOne($request);
                break;
            case 'stepTwo':
                # code...
                    return $this->steps($request,'\App\institutions');
                break;
            case 'stepThree':
                # code...
                    return $this->steps($request,'\App\empPastEmp');
            case 'stepFour':
                # code...
                    return $this->steps($request,'\App\Certification');
                break;
            case 'stepFive':
                # code...
                     return $this->steps($request,'\App\document');
                break;
            case 'stepSix': 
                # code...
                      return $this->steps($request,'\App\reference');
                break;
            case 'addJob':
                # code...
                    return $this->addJob($request);
                break;
            case 'decideApplicant':
                # code...
                    return $this->decideApplicant($request);
                break;
            case 'mailApplicant':
                # code...
                return $this->mailApplicant($request);
                break;

            default:
                # code...
                break;
        }
         }
        catch(\Exception $ex){
            return response()->json(['status'=>'error','message'=>$ex->getMessage()]);
        
        }
    }

    public function decideApplicant(Request $request){

        foreach ($request->ids as $id) {
            $updateStatus=\App\JobAppliedFor::updateOrCreate(['id'=>$id],['status'=>$request->status]);
            $this->notifyuser($updateStatus->user_id,"job/jobAppliedFor?user_id={{$updateStatus->user_id}}",$request->message);
        }
          return response()->json(['status'=>'success','message'=>'Operation Successfull']);
    }

    public function mailApplicant(Request $request){

          foreach ($request->ids as $id) {
              $updateStatus=\App\JobAppliedFor::where('id',$id)->first();
             $this->notifyuser($updateStatus->user_id,"/",$request->message);
            }
          return response()->json(['status'=>'success','message'=>'Mail Successfully Sent']);

    }

    public function notifyuser($user_id, $urltoview,$usermessage){
        $users=\App\User::where('id',$user_id)->get(); 
        $when=now()->addMinutes(10);
        foreach($users as $user):

            $user->notify((new UserNotification($user->name, $urltoview,$usermessage))->delay($when));
        endforeach;
    }

    public function delete($model,Request $request){
            $delete=$model::where('id',$request->id)->delete();
            return redirect('job/'.$request->url);
    }

    public function stepOne(Request $request){

        $data=$request->all();
        // dd($data);
        if(\Auth::guest()){
       if($request->password==$request->password_confirm){  $data['password']= bcrypt($request->password); } else { throw new \Exception("Password Not Match", 1); }
        }
        else{
            unset($data['password']);
        }
        $user=\App\User::updateOrCreate(['id'=>$request->id],$data);
        \Auth::login($user,true);
        if($request->has('job_id')){
         $appllyToJob=\App\JobAppliedFor::create(['user_id'=>$request->id, 'job_id'=>$request->job_id, 'status'=>0,'resume_id'=>0]);
        }
        return response()->json(['status'=>'success','message'=>'Operation Successfull']);
    }

    public function steps(Request $request,$model){
        $data=$request->all();
// dd($data);
      if($request->has('document')){

        $mime=$request->document->getClientOriginalextension();
        if(!(in_array($mime, $this->allowed))): throw new \Exception("Invalid File Type"); endif;
        $document=$request->file('document')->store('document');
        $data['document']=$document;       
        }

        $saveData=$model::updateOrCreate(['id'=>$request->id],$data); 
        return response()->json(['status'=>'success','message'=>'Operation Successfull']);
    }

    public function download(Request $request){ 

             $pushDownload=\App\document::where('id',$request->id)->value('document');//download?table=inventory)
             return response()->download(storage_path('app/'.$pushDownload));
 
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id,Request $request)
    {
        //
        switch ($id) {
            case 'apply':
                # code...
                    return $this->singleJob($request);
                break;
            case 'complete':
              # code... 
                  return $this->completeApplication($request);
              break;
            case 'appllyToJob':
                # code...               
                    return  $this->appllyToJob($request);
                break;
            case 'viewApplicant':
                # code...
                    return $this->viewApplicant($request);
                break;
            case 'delete':
                # code...
                    return $this->delete("\App\\".$request->model,$request);
                break;
              case 'download':
                # code...
                    return $this->download($request);
              case 'profile':
                  # code...
                    return $this->jobProfile($request,1);
                  break;
            case 'jobAppliedFor':
                # code...
                    return $this->jobAppliedFor($request);
                break;
                break;
            default:
                # code...
                break;
        }
    }

    private function completeApplication(Request $request){
      $application=\App\JobAppliedFor::where('user_id',$request->user()->id)->update(['complete'=>1]);

            return response()->json(['status'=>'success','message'=>'Operation Successful']);


    }

    private function jobAppliedFor(Request $request){

     $appliedfor=\App\JobAppliedFor::where('user_id',$request->user_id)->paginate(10);
      $state=\App\state::get();
        $level=\App\JobLevel::get();

     return view('category.myjobAppliedFor',compact('appliedfor','state','level'));
    }
    private function singleJob(Request $request){
        $job=\App\joblisting::where('id',$request->job_id)->first();
        $state=\App\state::get();
        $level=\App\JobLevel::get();
        if($request->ajax()){
            return response()->json(['status'=>'success','message'=>$job]);
        }
        return view('category.singleJob',compact('job','state','level'));
    }
    public function appllyToJob(Request $request){
     
        $id=(object) ['id'=>$request->user()->id];
        
        if($request->has('job_id')){
        $checkapplied=\App\JobAppliedFor::where(['user_id'=>\Auth::user()->id,'job_id'=>$request->job_id,'complete'=>1])->value('id');
        if($checkapplied){
            return redirect()->back()->with('message','You have Already applied for this position');
        }
       }

         $state=$this->jobProfile($id)[0];
        $level=$this->jobProfile($id)[1];
        $certifications=$this->jobProfile($id)[2];
        $pastEmps=$this->jobProfile($id)[3];
        $institutions=$this->jobProfile($id)[4];
        $documents=$this->jobProfile($id)[5];
        $doctypes=$this->jobProfile($id)[6];
        $refrees=$this->jobProfile($id)[7];
        return view('category.applyforjob',compact('documents','doctypes','state','level','certifications','pastEmps','institutions','refrees'));
    }

    public function jobProfile($request,$type=0){

         $user=\App\user::where('id',$request->id)->first();

         $state=\App\state::get();
        $level=\App\JobLevel::get();
         $certifications=\App\Certification::where('user_id',$request->id)->get();
        $pastEmps=\App\empPastEmp::where('emp_id',$request->id)->get();
        $institutions=\App\institutions::where('user_id',$request->id)->get();
        $documents=\App\document::where('user_id',$request->id)->get();
        $doctypes=\App\DocumentType::get();
        $refrees=\App\reference::get();

        if($type==1){
            if($request->ajax()){

         return view('category.partials.profile',compact('level','state','documents','doctypes','certifications','pastEmps','institutions','refrees','user')); 
            }
         return view('category.profile',compact('level','state','documents','doctypes','certifications','pastEmps','institutions','refrees','user')); 
        }
        return [$level,$state,$certifications,$pastEmps,$institutions,$documents,$doctypes,$refrees];
    } 


    public function addJob(Request $request){
        $data=$request->all();
        $data2=array_merge($data,['created_by'=>\Auth::user()->id]);
        $addJob=\App\joblisting::updateOrCreate(['id'=>$request->id],$data2);
        return response()->json(['status'=>'success','message'=>'Job Successfully Added']);
    }
    public function viewApplicant(Request $request){
        $applicantlists=\App\JobAppliedFor::where('job_id',$request->job_id)->with('user')->paginate(30);
        $jobtitle=\App\joblisting::where('id',$request->job_id)->value('title');
         $state=\App\state::get();
        $level=\App\JobLevel::get();
        return view('category.jobAppliedFor',compact('applicantlists','jobtitle','state','level'));
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
