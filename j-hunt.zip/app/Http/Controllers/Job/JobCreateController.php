<?php

namespace App\Http\Controllers\Job;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Jb\JbJob;
use App\Jb\JbRecruitmentType;
use App\User;




class JobCreateController extends Controller
{
    //

    function create(User $user,JbJob $job){
      return view('job.create',[
       'jb_recruitment_type_ids'=>JbRecruitmentType::all(),
       'user'=>$user
      ]);
    }

    function createAction(User $user,JbJob $job,Request $request){
       $data = $request->all();
       $job::create([
         'role'=>$data['role'],
         'description'=>$data['description'],
         'jb_recruitment_type_id'=>$data['jb_recruitment_type_id'],
         'salary_range'=>$data['salary_range'],
         'address'=>$data['address'],
         'created_by'=>$user->id
       ]); 
       return redirect('jobs')->with(['message'=>'Job created.']); 
    }

}
