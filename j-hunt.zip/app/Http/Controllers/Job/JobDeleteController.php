<?php

namespace App\Http\Controllers\Job;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Jb\JbJob;


class JobDeleteController extends Controller
{
    //

    function deleteAction(JbJob $job){
       $job->delete();
       return redirect('jobs')->with(['message'=>'Job Removed.']);
    }
}
