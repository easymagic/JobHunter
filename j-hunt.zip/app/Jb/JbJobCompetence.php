<?php

namespace App\Jb;

use Illuminate\Database\Eloquent\Model;

class JbJobCompetence extends Model
{
    //
    protected $table = 'jb_job_compentencies';

    function job(){
    	return $this->belongsTo(JbJob::class,'jb_job_id');
    }

    function compentence(){
    	return $this->belongsTo(JbCompentence::class,'jb_compentence_id');
    }
    
}
