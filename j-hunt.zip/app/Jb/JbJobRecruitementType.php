<?php

namespace App\Jb;

use Illuminate\Database\Eloquent\Model;

class JbJobRecruitementType extends Model
{
    //
    protected $table = 'jb_job_recruitment_type';

    function job(){
    	return $this->belongsTo(JbJob::class,'jb_job_id');
    }

    function recruitmentType(){
    	return $this->belongsTo(JbRecruitmentType::class,'jb_recruitment_type_id');
    }
    
}
