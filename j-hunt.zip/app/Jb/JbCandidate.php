<?php

namespace App\Jb;

use Illuminate\Database\Eloquent\Model;

class JbCandidate extends Model
{
    //
    protected $table = 'jb_candidates';


    function educations(){
    	return $this->hasMany(JbCandidateEducation::class,'jb_candidate_id');
    }

    function certifications(){
       return $this->hasMany(JbCandidateCertification::class,'jb_candidate_id');
    }


    function skills(){
       return $this->hasMany(JbCandidateSkill::class,'jb_candidate_id');
    }

    function competencies(){
    	return $this->hasMany(JbCandidateCompetency::class,'jb_candidate_id');
    }


}
