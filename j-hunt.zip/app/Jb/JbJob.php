<?php

namespace App\Jb;

use Illuminate\Database\Eloquent\Model;

class JbJob extends Model
{
    //
    protected $table = 'jb_jobs';
    protected $fillable = ['role','description','jb_recruitment_type_id','salary_range','address','created_by'];

    const UPDATED_AT = null;
    const CREATED_AT = null;


    function candidates(){
    	return $this->hasMany(JbCandidateJob::class,'jb_job_id');
    }

    function skills(){
     return $this->hasMany(JbJobSkill::class,'jb_job_id');
    }

    function certifications(){
      return $this->hasMany(JbJobCertification::class,'jb_job_id');	
    }

    function competencies(){
    	return $this->hasMany(JbJobCompetence::class,'jb_job_id');
    }

    function recruitmentTypes(){
    	return $this->hasMany(JbJobRecruitementType::class,'jb_job_id');
    }

}
