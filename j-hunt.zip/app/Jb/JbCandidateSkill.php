<?php

namespace App\Jb;

use Illuminate\Database\Eloquent\Model;

class JbCandidateSkill extends Model
{
    //
    protected $table = 'jb_candidate_skill';

    function candidate(){
    	return $this->belongsTo(JbCandidate::class,'jb_candidate_id');
    }

    function skill(){
    	return $this->belongsTo(JbSkill::class,'jb_skill_id');
    }


}
