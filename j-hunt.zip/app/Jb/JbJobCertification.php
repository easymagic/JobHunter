<?php

namespace App\Jb;

use Illuminate\Database\Eloquent\Model;

class JbJobCertification extends Model
{
    //
    protected $table = 'jb_job_certifications';

    function job(){
      return $this->belongsTo(JbJob::class,'jb_job_id');
    }

    function certification(){
    	return $this->belongsTo(JbCertification::class,'jb_certification_id');
    }
}
