<?php

namespace App\Jb;

use Illuminate\Database\Eloquent\Model;

class JbJobSkill extends Model
{
    //
    protected $table = "jb_job_skills";

    function job(){
    	return $this->belongsTo(JbJob::class,'jb_job_id');
    }

    function skill(){
    	return $this->belongsTo(JbSkill::class,'jb_skill_id');
    }

}
