<?php

namespace App\Jb;

use Illuminate\Database\Eloquent\Model;

class JbCandidateCertification extends Model
{
    //
    protected $table = 'jb_candidate_certifications';

    function candidate(){
    	return $this->belongsTo(JbCandidate::class,'jb_candidate_id');
    }

    function certification(){
    	return $this->belongsTo(JbCertification::class,'jb_certification_id');
    }
}
