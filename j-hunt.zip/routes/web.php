<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','HomeController@index');
    
        // $this->post('login', 'Auth\LoginController@login');

Auth::routes();

// Route::get('/home', 'HomeController@index');
// Route::resource('job', 'JobController');

Route::get('/test-home', 'HomeController@indexTest');

Route::get('/user-dashboard', 'HomeController@userDashboard')->middleware('auth')->name('user-dashboard');

Route::get('/change-password/{user}', 'Auth\ChangePasswordController@changePassword')->middleware('auth');

Route::post('/change-password/{user}', 'Auth\ChangePasswordController@changePasswordAction')->middleware('auth');

Route::get('/user-profile/{user}','Auth\UserProfileController@profile')->middleware('auth');

Route::post('/user-profile/{user}','Auth\UserProfileController@profileAction')->middleware('auth');



//jobs
Route::get('/jobs','Job\JobListController@index')->middleware('auth');

Route::get('/jobs/add/{user}','Job\JobCreateController@create')->middleware('auth');

Route::post('/jobs/add/{user}','Job\JobCreateController@createAction')->middleware('auth');

Route::get('/jobs/{job}','Job\JobUpdateController@update')->middleware('auth');

Route::post('/jobs/{job}','Job\JobUpdateController@updateAction')->middleware('auth');

Route::post('/jobs/{job}/delete','Job\JobDeleteController@deleteAction')->middleware('auth');



// recruitment-types
Route::get('/recruitment-types','RecruitmentType\RecruitmentTypeListController@index')->middleware('auth');

Route::get('/recruitment-types/add/{user}','RecruitmentType\RecruitmentTypeCreateController@create')->middleware('auth');

Route::post('/recruitment-types/add/{user}','RecruitmentType\RecruitmentTypeCreateController@createAction')->middleware('auth');

Route::get('/recruitment-types/{recruitmentType}','RecruitmentType\RecruitmentTypeUpdateController@update')->middleware('auth');

Route::post('/recruitment-types/{recruitmentType}','RecruitmentType\RecruitmentTypeUpdateController@updateAction')->middleware('auth');

Route::post('/recruitment-types/{recruitmentType}/delete','RecruitmentType\RecruitmentTypeDeleteController@deleteAction')->middleware('auth');




///certifications
Route::get('/certifications','Certification\CertificationListController@index')->middleware('auth');

Route::get('/certifications/add/{user}','Certification\CertificationCreateController@create')->middleware('auth');

Route::post('/certifications/add/{user}','Certification\CertificationCreateController@createAction')->middleware('auth');

Route::get('/certifications/{certification}','Certification\CertificationUpdateController@update')->middleware('auth');

Route::post('/certifications/{certification}','Certification\CertificationUpdateController@updateAction')->middleware('auth');

Route::post('/certifications/{certification}/delete','Certification\CertificationDeleteController@deleteAction')->middleware('auth');




///competencies
Route::get('/competencies','Competence\CompetenceListController@index')->middleware('auth');

Route::get('/competencies/add/{user}','Competence\CompetenceCreateController@create')->middleware('auth');

Route::post('/competencies/add/{user}','Competence\CompetenceCreateController@createAction')->middleware('auth');

Route::get('/competencies/{competence}','Competence\CompetenceUpdateController@update')->middleware('auth');

Route::post('/competencies/{competence}','Competence\CompetenceUpdateController@updateAction')->middleware('auth');

Route::post('/competencies/{competence}/delete','Competence\CompetenceDeleteController@deleteAction')->middleware('auth');




///education
Route::get('/educations','Education\EducationListController@index')->middleware('auth');

Route::get('/educations/add/{user}','Education\EducationCreateController@create')->middleware('auth');

Route::post('/educations/add/{user}','Education\EducationCreateController@createAction')->middleware('auth');

Route::get('/educations/{education}','Education\EducationUpdateController@update')->middleware('auth');

Route::post('/educations/{education}','Education\EducationUpdateController@updateAction')->middleware('auth');

Route::post('/educations/{education}/delete','Education\EducationDeleteController@deleteAction')->middleware('auth');




///skills
Route::get('/skills','Skill\SkillListController@index')->middleware('auth');

Route::get('/skills/add/{user}','Skill\SkillCreateController@create')->middleware('auth');

Route::post('/skills/add/{user}','Skill\SkillCreateController@createAction')->middleware('auth');

Route::get('/skills/{skill}','Skill\SkillUpdateController@update')->middleware('auth');

Route::post('/skills/{skill}','Skill\SkillUpdateController@updateAction')->middleware('auth');

Route::post('/skills/{skill}/delete','Skill\SkillDeleteController@deleteAction')->middleware('auth');
