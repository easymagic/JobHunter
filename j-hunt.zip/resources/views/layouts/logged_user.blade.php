@section('content')
<div class="col-lg-2 sidebar">
  @include('sidebars.admin_sidebar')
</div>
<div class="col-lg-10 post-list">
 @yield('inner-content')
</div>
@endsection