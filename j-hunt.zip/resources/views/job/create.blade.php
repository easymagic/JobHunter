@extends('layouts.main')

@extends('layouts.logged_user')

@section('inner-content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            
                <!-- <div class="card-header">{{ __('Change Password') }}</div> -->

<div style="
    border-bottom: 3px solid #8c76f7;
    margin-bottom: 17px;
    font-size: 18px;
">
    Create Job.
</div>

@include('notifications.message')

<div class="col-md-12" align="right">
	<a href="/jobs" class="btn btn-primary btn-sm">Back</a>
</div>

            
                    <form method="POST" action="/jobs/add/{{$user->id}}">
                        @csrf

                        <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right">{{ __('Role') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control" name="role" value="" required autofocus required="">

                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right">{{ __('Description') }}</label>

                            <div class="col-md-6">
                            	<textarea class="form-control" name="description" required=""></textarea>

                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right">{{ __('Recruitment Type') }}</label>

                            <div class="col-md-6">
                                <select name="jb_recruitment_type_id" class="form-control" required="">
                                	@foreach ($jb_recruitment_type_ids as $jb_recruitment_type_id)
                                    <option value="{{$jb_recruitment_type_id->id}}">{{$jb_recruitment_type_id->name}}</option>
                                    @endforeach
                                </select>

                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right">{{ __('Salary Range') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control" name="salary_range" required autofocus>

                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right">{{ __('Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control" name="address"  required autofocus>

                            </div>
                        </div>



                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Create Job') }}
                                </button>

                            </div>
                        </div>
                    </form>
                
        </div>
    </div>

<div class="col-lg-12" style="margin: 11.4%;"></div>
</div>

@endsection
